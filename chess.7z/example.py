# -*- coding: utf-8 -*-
"""
Created on Sat Jan 12 00:24:07 2019

@author: over2
"""

import numpy as np

print(np.zeros((8,8,5)))